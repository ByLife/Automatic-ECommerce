<?php 

echo json_encode([
    'message' => 'Hello from API, Project for Ynov',
    'author' => "BLF",
    'email' => "bylife@bylife.fr"
]);

?>