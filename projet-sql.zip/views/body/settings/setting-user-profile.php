<div class="card-inner-group" data-simplebar>
    <div class="card-inner">
        <div class="user-card">
            <div class="user-info">
                <span class="lead-text"><?= $user['displayname']; ?></span>
                <span class="sub-text"><?=  $user['email']; ?></span>
            </div>
        </div><!-- .user-card -->
    </div><!-- .card-inner -->
    <!-- .card-inner -->
    <?php include_once "./views/body/settings/settings-menu.php"; ?>
    <!-- .card-inner -->
</div>
