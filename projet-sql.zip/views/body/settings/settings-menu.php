<div class="card-inner p-0">
    <ul class="link-list-menu">
        <li><a href="./client/profile"><em class="icon ni ni-user-fill-c"></em><span>Personal Infomation</span></a></li>
        <li><a href="./client/activity"><em class="icon ni ni-activity-round-fill"></em><span>Account Activity</span></a></li>
    </ul>
</div>