<?php 
namespace Project\App\Controller;

class PostsController {

}
?>

