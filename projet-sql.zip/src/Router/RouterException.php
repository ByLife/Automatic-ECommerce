<?php 
namespace Project\App\Router;

class RouterException extends \Exception {
    
}

?>