<?php 

require_once './config.php'; // Load config file

require_once './src/handler.php'; // Load handler file

?>